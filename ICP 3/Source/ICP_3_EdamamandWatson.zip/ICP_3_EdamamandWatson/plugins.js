

var nutritionmodule= angular.module('nutr', []);
nutritionmodule.controller("Nutrcontroller", function($scope, $http) {

    $scope.getRecipe = function() {
        var item=$scope.search;
        $http.get('https://api.edamam.com/api/nutrition-data?app_id=e6884fa6&app_key=bb6fd9842b046e4f2ec510a4dad47863&ingr="'+item+'"').success(function(data) {
            console.log(data);
            cal = data.calories;
            weight = data.totalWeight;
            document.getElementById("nutrition").innerHTML ="Total calories is:"+cal+"<br>"+"Total weight is:"+weight;

        })
    }

    $scope.convertToText = function() {
        var text = $scope.getspeech;
        var username = "d87a3a59-a87b-4fa3-83db-8861b4754bf2";
        var password = "eQuITuuizWm7";
        var url = 'https://stream.watsonplatform.net/text-to-speech/api/v1/synthesize?voice=en-US_AllisonVoice&accept=audio/wav&text=' + text;
        $http.post(url).then(function(response){});
        document.getElementById("speech").src=url;
        document.getElementById("speech").play();


    }

});







