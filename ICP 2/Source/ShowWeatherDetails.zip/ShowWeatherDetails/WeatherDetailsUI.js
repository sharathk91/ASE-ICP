
angular.module('ShowWeatherDetails', [])
    .controller('GetweatherAPI', function($scope, $http) {

        $scope.getWeather = function() {
            var state=$scope.state;
            var city = $scope.city;

            $http.get('https://api.wunderground.com/api/aad4368691e706e9/conditions/q/'+state+'/'+city+'%20.json').success(function(data) {
                console.log(data);

                temp = data.current_observation.temp_f;
                icon = data.current_observation.icon_url;
                weather = data.current_observation.weather;
                wind = data.current_observation.wind_degrees;
                humidity= data.current_observation.relative_humidity;
                console.log(temp);
                $scope.currentweather = {
                    html: "Current Temperature at is :" + temp + " &deg; F <br>Weather :" + weather+"<br> Wind: "+wind+"&deg<br>Humidity: "+humidity
                }
                $scope.currentIcon = {
                    html: "<img src='" + icon + "'/>"
                }

            })
        }

    });
