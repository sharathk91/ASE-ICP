
    var MongoClient = require('mongodb').MongoClient;
    var assert = require('assert');
    var url = 'mongodb://root:1234@ds227565.mlab.com:27565/aseproject';


    var findUserwithphoneno = function (db, callback) {
      var dbo = db.db("aseproject");
      var cursor = dbo.collection('users').find({"phoneno": "8164057802"});
      cursor.each(function (err, doc) {
        assert.equal(err, null);
        if (doc != null) {
          console.log("Class ID:" + doc.classid);
          console.log("First Name:" + doc.fname);
          console.log("Last Name:" + doc.lname);
          console.log("Phone no:" + doc.phoneno);
          console.log("Email:" + doc.email);
          console.log("City:" + doc.city);
          console.log("State:" + doc.state);

        }
      });
    }

    MongoClient.connect(url, function (err, db) {
      assert.equal(null, err);
      findUserwithphoneno(db, function () {
        db.close();
      });
    });
