var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://root:1234@ds227565.mlab.com:27565/aseproject';

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("aseproject");
  var myobj = {
    classid: "14",
    fname: "Rohith",
    lname: "Koppu",
    phoneno: "8174057802",
    email: "rk3w7@mail.umkc.edu",
    city: "kansas",
    state: "missouri"
  };
  dbo.collection("users").insertOne(myobj, function(err, res) {
    if (err) throw err;
    console.log("1 document inserted");
    db.close();
  });
});
